﻿using BCrypt;
using BCrypt.Net;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.Security.Cryptography;

namespace CLC_Milestone.Models
{
    public class Users
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [BsonElement("username")]
        public string userName { get; set; }
        [BsonElement("salt")]
        public string salt { get; set; }
        [BsonElement("password")]
        public string hashPass { get; set; }
        [BsonElement("firstName")]
        public string firstName { get; set; }
        [BsonElement("lastName")]
        public string lastName { get; set; }
        [BsonElement("email")]
        public string email { get; set; }
        [BsonElement("roles")]
        public string roles { get; set; }

        //Encrypts the plain text password using an already assigned salt and BCrypt
        public string EncryptPassword(string password)
        {
            string fullPass = this.salt + password; //concatentate the salt and plain text password
            string encryptPass = BCrypt.Net.BCrypt.EnhancedHashPassword(fullPass);
            return encryptPass;
        }
        
        //Encrypt a brand new password and set the initial salt for the account
        public string EncryptNewPass(string password)
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            byte[] buffer = new byte[1024];

            rng.GetBytes(buffer);
            this.salt = BitConverter.ToString(buffer); // Code for generating salt from user Randolpho on https://stackoverflow.com/questions/3063116/how-to-easily-salt-a-password-in-a-c-sharp-windows-form-application 
            string fullPass = this.salt + password;
            string encryptPass = BCrypt.Net.BCrypt.EnhancedHashPassword(fullPass);
            this.hashPass = encryptPass;
            return encryptPass;

        }

    }
}
