﻿using CLC_Milestone.Models;
using MongoDB.Driver;
using System.Runtime.CompilerServices;

namespace CLC_Milestone.Controllers
{
   
    public class UserService
    {
        private readonly IMongoCollection<Users> _usersCollection;
        public UserService(IMongoCollection<Users> userCollection)
        {
            _usersCollection = userCollection;
        }

        //Get all users
        public async Task<List<Users>> GetUsersAsync() =>
            await _usersCollection.Find(_ => true).ToListAsync();

        //Get user by id
        public async Task<Users?> GetAsync(string id) =>
            await _usersCollection.Find(x => x.Id == id).FirstOrDefaultAsync();

        //Get user by name
        public async Task<Users> GetNameAsync(string username) =>
            await _usersCollection.Find(x => x.userName == username).FirstOrDefaultAsync();

        //Create new user
        public async Task CreateAsync(Users newUser) =>
            await _usersCollection.InsertOneAsync(newUser);

        //Update user by id
        public async Task UpdateIdAsync(string id, Users updateUser) =>
            await _usersCollection.ReplaceOneAsync(x => x.Id == id, updateUser);

        //Delete user by id
        public async Task DeleteAsync(string id) =>
            await _usersCollection.DeleteManyAsync(x => x.Id == id);

        //Code sourced from Create a web API with ASP.NET Core and MongoDB, 2025. https://learn.microsoft.com/en-us/aspnet/core/tutorials/first-mongo-app?view=aspnetcore-9.0&tabs=visual-studio
    }
}
